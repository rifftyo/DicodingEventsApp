package com.rifftyo.dicodingeventsapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.rifftyo.dicodingeventsapp.data.response.ListEventsItem
import com.rifftyo.dicodingeventsapp.databinding.FragmentHomeBinding
import com.rifftyo.dicodingeventsapp.ui.adapter.EventsAdapter
import com.rifftyo.dicodingeventsapp.ui.viewmodel.MainViewModel

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val mainViewModel by viewModels<MainViewModel>()

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val layoutManagerHorizontal = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.rvHomeUpComing.layoutManager = layoutManagerHorizontal

        val layoutManagerVertical = StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL)
        binding.rvHomeFinished.layoutManager = layoutManagerVertical

        if (mainViewModel.listEventUpComing.value.isNullOrEmpty()) {
            mainViewModel.getDicodingEvents(1)
        }

        if (mainViewModel.listEventFinished.value.isNullOrEmpty()) {
            mainViewModel.getDicodingEvents(0)
        }

        mainViewModel.listEventUpComing.observe(viewLifecycleOwner) { listEventUpComing ->
            setEventsDataUpComing(listEventUpComing)
        }

        mainViewModel.listEventFinished.observe(viewLifecycleOwner) { listEventFinished ->
            setEventsDataFinished(listEventFinished.take(5))
        }

        mainViewModel.isLoading.observe(viewLifecycleOwner) {
            showLoading(it)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun setEventsDataUpComing(listEventsData: List<ListEventsItem>) {
        val adapter = EventsAdapter(listEventsData)
        binding.rvHomeUpComing.adapter = adapter
    }

    private fun setEventsDataFinished(listEventsData: List<ListEventsItem>) {
        val adapter = EventsAdapter(listEventsData)
        binding.rvHomeFinished.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBarHome.visibility = View.VISIBLE
        } else {
            binding.progressBarHome.visibility = View.GONE
        }
    }
}